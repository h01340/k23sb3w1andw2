package sb3.sb3w1And2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb3W1And2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
