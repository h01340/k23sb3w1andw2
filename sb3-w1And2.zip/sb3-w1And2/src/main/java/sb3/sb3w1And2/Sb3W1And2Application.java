package sb3.sb3w1And2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb3W1And2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb3W1And2Application.class, args);
	}

}
